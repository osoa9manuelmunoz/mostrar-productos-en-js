import { Router } from 'express'
import ProductsView from '../view/ProductsView'

export default class ProductsRouter {
  router: Router

  constructor (private readonly productsView: ProductsView) {
    this.router = Router()
    this.routes()
  }

  routes = (): void => {
    this.router.get('/next', this.productsView.next)
    this.router.get('/anterior', this.productsView.anterior)
    this.router.get('/', this.productsView.index)
    this.router.get('/delete/:id', this.productsView.delete)
    this.router.post('/update/:id', this.productsView.update)
  }
}
