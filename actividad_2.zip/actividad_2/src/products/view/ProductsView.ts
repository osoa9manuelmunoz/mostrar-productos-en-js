import { Request, Response } from 'express'
import ProductsModel from '../model/ProductsModel'

export default class ProductsView {
  constructor (private readonly productsModel: ProductsModel) { }

  index = (_: Request, res: Response): void => {
    this.productsModel.getProductById(1).then((product) => {
      res.render('ProductsTemplate', { product })
    }).catch((err) => {
      console.log(err)
      res.render('ProductsTemplate', { product: null })
    })
  }

  next = async (req: Request, res: Response): Promise<void> => {
    const { idp } = req.query
    const currentProductId = Number(idp)
    const products = await this.productsModel.getProducts()
    const currentIndex = products.findIndex((product) => product.id === currentProductId)
    let nextProductIndex = currentIndex + 1
    if (nextProductIndex === products.length) {
      nextProductIndex = 0
    }
    const nextProduct = products[nextProductIndex]
    res.render('ProductsTemplate', { product: nextProduct })
  }

  anterior = async (req: Request, res: Response): Promise<void> => {
    const { idp } = req.query
    const currentProductId = Number(idp)
    const products = await this.productsModel.getProducts()
    const currentIndex = products.findIndex((product) => product.id === currentProductId)
    let prevProductIndex = currentIndex - 1
    if (prevProductIndex < 0) {
      prevProductIndex = products.length - 1
    }
    const prevProduct = products[prevProductIndex]
    res.render('ProductsTemplate', { product: prevProduct })
  }

  delete = async (req: Request, res: Response): Promise<void> => {
    const { id } = req.params
    try {
      const products = await this.productsModel.getProducts()
      const productIndex = products.findIndex((product) => product.id === Number(id))
      if (productIndex !== -1) {
        await this.productsModel.getDeleteById(Number(id))
        if (productIndex > 0) {
          const previousProductId = products[productIndex - 1].id
          res.redirect(`/next?idp=${previousProductId}`)
        } else {
          res.redirect('/')
        }
      } else {
        res.redirect('/')
      }
    } catch (error) {
      console.log(error)
      res.redirect('/')
    }
  }

  update = async (req: Request, res: Response): Promise<void> => {
    const { id } = req.params
    const { title, description, price } = req.body
  
    try {
      await this.productsModel.updateProduct(Number(id), title, description, price)
      res.redirect('/?message=update_success')
    } catch (error) {
      console.log(error)
      res.redirect('/?message=update_error')
    }
  }
}
